import { createPoll } from "ags/time";
import { sh } from "../utils/helpers";
import { toggleCC } from "../utils/controlCenter";

export function Weather() {
  const weather = createPoll("──°F", 600000, () =>
    sh("curl -s 'wttr.in/?format=%t'", "──°F"),
  );

  return (
    <button class="weather-button" onClicked={toggleCC}>
      <box>
        <label class="weather-icon" label="󰖐" />
        <label class="weather-temp" label={weather} />
      </box>
    </button>
  );
}
