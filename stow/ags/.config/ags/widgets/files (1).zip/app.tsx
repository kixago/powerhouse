import app from "ags/gtk4/app";
import { css } from "./style";
import { Bar } from "./widgets/Bar";
import { ControlCenter } from "./windows/ControlCenter";

app.start({
  css,
  main() {
    for (const monitor of app.get_monitors()) {
      if (monitor.connector === "HDMI-A-1") {
        Bar({ gdkmonitor: monitor });
        ControlCenter({ gdkmonitor: monitor });
      }
    }
  },
});
