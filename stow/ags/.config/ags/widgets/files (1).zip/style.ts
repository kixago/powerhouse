// ── Design Tokens ────────────────────────────────────────────────────────────

export const colors = {
  blue:        "rgba(122, 162, 247, 0.9)",
  blueSubtle:  "rgba(122, 162, 247, 0.6)",
  white:       "rgba(255, 255, 255, 0.9)",
  whiteDim:    "rgba(255, 255, 255, 0.6)",
  whiteFaint:  "rgba(255, 255, 255, 0.3)",
  gold:        "rgba(255, 200, 100, 0.8)",
  pill:        "rgba(0, 0, 0, 0.7)",
  hover:       "rgba(255, 255, 255, 0.1)",
};

export const font = {
  family: '"CaskaydiaCove Nerd Font", "JetBrainsMono Nerd Font", monospace',
  sm:     "10px",
  md:     "11px",
  base:   "12px",
  icon:   "13px",
  iconLg: "14px",
};

export const radius = {
  pill:   "14px",
  button: "10px",
};

export const spacing = {
  barMargin:    "6px 12px",
  pillPadding:  "4px 8px",
  btnPadding:   "2px 8px",
};

// ── CSS ───────────────────────────────────────────────────────────────────────

export const css = `
* {
  font-family: ${font.family};
}

window#bar {
  background: transparent;
}

.bar-container {
  background: transparent;
  margin: ${spacing.barMargin};
}

/* ── Pills ── */

.section {
  background: ${colors.pill};
  border-radius: ${radius.pill};
  padding: ${spacing.pillPadding};
}

.section-center-group {
  background: transparent;
}

.section-center {
  margin-right: 8px;
}

.section-weather {
  padding: 4px 12px;
}

/* ── Buttons ── */

.section-left button,
.section-right button,
.section-center button,
.section-weather button {
  background: transparent;
  padding: ${spacing.btnPadding};
  border-radius: ${radius.button};
}

.section-left button:hover,
.section-right button:hover,
.section-center button:hover,
.section-weather button:hover {
  background: ${colors.hover};
}

/* ── Clock ── */

.clock {
  font-size: ${font.base};
  color: ${colors.white};
  font-weight: 500;
  letter-spacing: 0.3px;
}

/* ── Weather ── */

.weather-icon {
  font-size: ${font.iconLg};
  color: ${colors.blue};
  margin-right: 6px;
}

.weather-temp {
  font-size: ${font.base};
  color: ${colors.white};
}

/* ── System Stats ── */

.stat-icon {
  font-size: ${font.icon};
  color: ${colors.blue};
  margin-right: 4px;
}

.stat-value {
  font-size: ${font.md};
  color: ${colors.white};
  min-width: 28px;
}

.stat-temp {
  font-size: ${font.sm};
  color: ${colors.gold};
  margin-left: 2px;
  margin-right: 4px;
}

.stat-separator {
  color: ${colors.whiteFaint};
  margin: 0 6px;
}

/* ── Volume ── */

.icon {
  font-size: ${font.iconLg};
  color: ${colors.blue};
}

.volume-value {
  font-size: ${font.md};
  color: ${colors.white};
  margin-left: 6px;
  min-width: 28px;
}

/* ── Network ── */

.network-button {
  margin-right: 4px;
}

/* ════════════════════════════════════════════════════════════════
   CONTROL CENTER
   ════════════════════════════════════════════════════════════════ */

.cc-root {
  min-width: 900px;
  background: rgba(15, 17, 26, 0.55);
  border-radius: 20px;
  border: 1px solid rgba(255, 255, 255, 0.08);
  padding: 20px;
  transition: opacity 400ms ease, margin-top 400ms cubic-bezier(0.4, 0, 0.2, 1);
}

.cc-section {
  background: rgba(255, 255, 255, 0.04);
  border-radius: 14px;
  border: 1px solid rgba(255, 255, 255, 0.06);
  padding: 16px;
  margin: 6px;
}

.cc-section-title {
  font-size: 11px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.4);
  letter-spacing: 1px;
  margin-bottom: 10px;
}

.cc-loading {
  color: rgba(255, 255, 255, 0.4);
  font-size: 12px;
}

.cc-top-row,
.cc-bottom-row {
  background: transparent;
}

/* ── Calendar ── */

.cc-calendar {
  min-width: 300px;
}

.cal-header {
  margin-bottom: 8px;
  background: transparent;
}

.cal-month-label {
  font-size: 14px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.9);
}

.cal-nav-btn {
  background: rgba(255, 255, 255, 0.06);
  border-radius: 8px;
  padding: 2px 10px;
  color: rgba(255, 255, 255, 0.7);
  font-size: 16px;
}

.cal-nav-btn:hover {
  background: rgba(122, 162, 247, 0.2);
  color: rgba(122, 162, 247, 1);
}

.cal-dow-row {
  background: transparent;
  margin-bottom: 4px;
}

.cal-dow {
  font-size: 10px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.35);
  letter-spacing: 0.5px;
}

.cal-row {
  background: transparent;
}

.cal-day {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.75);
  padding: 4px 0;
  border-radius: 8px;
  min-width: 32px;
}

.cal-empty {
  color: transparent;
}

.cal-today {
  background: rgba(122, 162, 247, 0.3);
  color: rgba(122, 162, 247, 1);
  font-weight: 700;
}

/* ── Weather ── */

.weather-current {
  background: transparent;
  margin-bottom: 12px;
}

.weather-big-icon {
  font-size: 52px;
  color: rgba(122, 162, 247, 0.95);
  margin-right: 16px;
}

.weather-big-temp {
  font-size: 36px;
  font-weight: 700;
  color: rgba(255, 255, 255, 0.95);
}

.weather-big-desc {
  font-size: 13px;
  color: rgba(255, 255, 255, 0.5);
  margin-top: 2px;
}

.weather-details {
  background: rgba(255, 255, 255, 0.03);
  border-radius: 10px;
  padding: 10px 0;
  margin-bottom: 14px;
}

.weather-detail-item {
  hexpand: true;
  padding: 0 8px;
}

.detail-icon {
  font-size: 18px;
  color: rgba(122, 162, 247, 0.8);
  margin-bottom: 4px;
}

.detail-val {
  font-size: 13px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.9);
}

.detail-lbl {
  font-size: 10px;
  color: rgba(255, 255, 255, 0.4);
  margin-top: 2px;
}

.weather-forecast {
  background: transparent;
}

.forecast-day {
  padding: 8px 4px;
  border-radius: 10px;
}

.forecast-day:hover {
  background: rgba(255, 255, 255, 0.05);
}

.forecast-dow {
  font-size: 11px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.45);
  margin-bottom: 4px;
}

.forecast-icon {
  font-size: 20px;
  color: rgba(122, 162, 247, 0.9);
  margin-bottom: 4px;
}

.forecast-hi {
  font-size: 13px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.9);
}

.forecast-lo {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.4);
  margin-top: 1px;
}

/* ── System Stats ── */

.cc-system {
  min-width: 380px;
}

.sys-row {
  background: transparent;
  margin-bottom: 12px;
}

.sys-icon {
  font-size: 16px;
  color: rgba(122, 162, 247, 0.9);
  margin-right: 8px;
  min-width: 20px;
}

.sys-label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
  min-width: 36px;
  margin-right: 10px;
}

.stat-bar-track {
  background: rgba(255, 255, 255, 0.08);
  border-radius: 6px;
  min-height: 8px;
  hexpand: true;
  margin: 0 10px;
}

.stat-bar-fill {
  border-radius: 6px;
  min-height: 8px;
  transition: min-width 500ms ease;
}

.sys-val {
  font-size: 12px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.85);
  min-width: 38px;
}

.sys-temp {
  font-size: 11px;
  color: rgba(255, 200, 100, 0.8);
  margin-left: 6px;
  min-width: 34px;
}

/* ── Volume ── */

.vol-row {
  background: transparent;
}

.vol-icon {
  font-size: 22px;
  color: rgba(122, 162, 247, 0.9);
  margin-right: 14px;
}

.vol-track {
  background: rgba(255, 255, 255, 0.08);
  border-radius: 8px;
  min-height: 12px;
}

.vol-fill {
  background: linear-gradient(to right, rgba(122,162,247,0.7), rgba(122,162,247,1));
  border-radius: 8px;
  min-height: 12px;
  transition: min-width 150ms ease;
}

.vol-segment {
  background: transparent;
  min-height: 12px;
  padding: 0;
}

.vol-val {
  font-size: 13px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.85);
  min-width: 40px;
  margin-left: 14px;
}
`;
