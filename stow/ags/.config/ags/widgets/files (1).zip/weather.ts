import { sh } from "./helpers";

export interface CurrentWeather {
  temp:      string;
  feelsLike: string;
  humidity:  string;
  windSpeed: string;
  windDir:   string;
  desc:      string;
  icon:      string;
}

export interface ForecastDay {
  date:    string;
  high:    string;
  low:     string;
  desc:    string;
  icon:    string;
}

export interface WeatherData {
  current:  CurrentWeather;
  forecast: ForecastDay[];
}

const CONDITION_ICONS: Record<number, string> = {
  113: "󰖙",  // Sunny
  116: "󰖕",  // Partly cloudy
  119: "󰖐",  // Cloudy
  122: "󰖐",  // Overcast
  143: "󰖑",  // Mist
  176: "󰖗",  // Patchy rain
  179: "󰖘",  // Patchy snow
  182: "󰖗",  // Sleet
  185: "󰖘",  // Freezing drizzle
  200: "󰖓",  // Thunder
  227: "󰖘",  // Blowing snow
  230: "󰖘",  // Blizzard
  248: "󰖑",  // Fog
  260: "󰖑",  // Freezing fog
  263: "󰖗",  // Light drizzle
  266: "󰖗",  // Drizzle
  281: "󰖗",  // Freezing drizzle
  284: "󰖗",  // Heavy freezing drizzle
  293: "󰖗",  // Patchy light rain
  296: "󰖗",  // Light rain
  299: "󰖔",  // Moderate rain
  302: "󰖔",  // Moderate rain
  305: "󰖔",  // Heavy rain
  308: "󰖔",  // Very heavy rain
  311: "󰖗",  // Light freezing rain
  314: "󰖗",  // Moderate freezing rain
  317: "󰖘",  // Light sleet
  320: "󰖘",  // Moderate sleet
  323: "󰖘",  // Patchy light snow
  326: "󰖘",  // Light snow
  329: "󰖘",  // Patchy moderate snow
  332: "󰖘",  // Moderate snow
  335: "󰖘",  // Patchy heavy snow
  338: "󰖘",  // Heavy snow
  350: "󰖘",  // Ice pellets
  353: "󰖗",  // Light rain shower
  356: "󰖔",  // Moderate rain shower
  359: "󰖔",  // Torrential rain shower
  362: "󰖘",  // Light sleet showers
  365: "󰖘",  // Moderate sleet showers
  368: "󰖘",  // Light snow showers
  371: "󰖘",  // Moderate snow showers
  374: "󰖘",  // Light ice pellet showers
  377: "󰖘",  // Moderate ice pellet showers
  386: "󰖓",  // Patchy light rain with thunder
  389: "󰖓",  // Moderate rain with thunder
  392: "󰖓",  // Patchy light snow with thunder
  395: "󰖓",  // Moderate snow with thunder
};

function conditionIcon(code: number): string {
  return CONDITION_ICONS[code] ?? "󰖐";
}

const DAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export async function fetchWeather(): Promise<WeatherData | null> {
  try {
    const raw = await sh("curl -s 'wttr.in/?format=j1'", "");
    if (!raw) return null;
    const json = JSON.parse(raw);

    const cur     = json.current_condition[0];
    const code    = parseInt(cur.weatherCode);
    const current: CurrentWeather = {
      temp:      `${cur.temp_F}°F`,
      feelsLike: `${cur.FeelsLikeF}°F`,
      humidity:  `${cur.humidity}%`,
      windSpeed: `${cur.windspeedMiles} mph`,
      windDir:   cur.winddir16Point,
      desc:      cur.weatherDesc[0].value,
      icon:      conditionIcon(code),
    };

    const forecast: ForecastDay[] = json.weather.slice(0, 5).map((day: any) => {
      const d    = new Date(day.date);
      const code = parseInt(day.hourly[4]?.weatherCode ?? day.hourly[0]?.weatherCode ?? "113");
      return {
        date: DAY_NAMES[d.getDay()],
        high: `${day.maxtempF}°`,
        low:  `${day.mintempF}°`,
        desc: day.hourly[4]?.weatherDesc[0]?.value ?? "",
        icon: conditionIcon(code),
      };
    });

    return { current, forecast };
  } catch {
    return null;
  }
}
