import app from "ags/gtk4/app";
import { Astal, Gtk } from "ags/gtk4";
import Gdk from "gi://Gdk?version=4.0";
import GLib from "gi://GLib";
import { onCleanup, createSignal, createEffect } from "ags";
import { createPoll } from "ags/time";
import { sh } from "../utils/helpers";
import { fetchWeather, WeatherData } from "../utils/weather";
import { ccVisible, setCCVisible } from "../utils/controlCenter";

// ── Helpers ───────────────────────────────────────────────────────────────────

function pad(n: number) { return n.toString().padStart(2, "0"); }

// ── Calendar Section ──────────────────────────────────────────────────────────

function CalendarSection() {
  const today    = GLib.DateTime.new_now_local();
  const [year,   setYear]   = createSignal(today.get_year());
  const [month,  setMonth]  = createSignal(today.get_month()); // 1–12
  const todayDay = today.get_day_of_month();
  const todayM   = today.get_month();
  const todayY   = today.get_year();

  const MONTH_NAMES = [
    "", "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
  ];
  const DAY_HEADERS = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];

  function prevMonth() {
    if (month() === 1) { setMonth(12); setYear(year() - 1); }
    else setMonth(month() - 1);
  }
  function nextMonth() {
    if (month() === 12) { setMonth(1); setYear(year() + 1); }
    else setMonth(month() + 1);
  }

  function buildGrid() {
    const y = year(), m = month();
    const first = GLib.DateTime.new_local(y, m, 1, 0, 0, 0);
    const startDow = first.get_day_of_week() % 7; // Sun=0
    const daysInMonth = new Date(y, m, 0).getDate();
    const cells: (number | null)[] = [];
    for (let i = 0; i < startDow; i++) cells.push(null);
    for (let d = 1; d <= daysInMonth; d++) cells.push(d);
    while (cells.length % 7 !== 0) cells.push(null);
    return cells;
  }

  return (
    <box class="cc-section cc-calendar" vertical>
      {/* Month nav */}
      <box class="cal-header">
        <button class="cal-nav-btn" onClicked={prevMonth}>
          <label label="󰍞" />
        </button>
        <label
          class="cal-month-label"
          hexpand
          halign={Gtk.Align.CENTER}
          label={`${MONTH_NAMES[month()]} ${year()}`}
        />
        <button class="cal-nav-btn" onClicked={nextMonth}>
          <label label="󰍟" />
        </button>
      </box>

      {/* Day-of-week headers */}
      <box class="cal-dow-row">
        {DAY_HEADERS.map(d => (
          <label class="cal-dow" hexpand label={d} halign={Gtk.Align.CENTER} />
        ))}
      </box>

      {/* Day grid — rows of 7 */}
      {(() => {
        const cells = buildGrid();
        const rows: JSX.Element[] = [];
        for (let r = 0; r < cells.length / 7; r++) {
          const row = cells.slice(r * 7, r * 7 + 7);
          rows.push(
            <box class="cal-row">
              {row.map(d => {
                const isToday = d !== null && d === todayDay
                  && month() === todayM && year() === todayY;
                return (
                  <label
                    hexpand
                    halign={Gtk.Align.CENTER}
                    class={`cal-day${d === null ? " cal-empty" : ""}${isToday ? " cal-today" : ""}`}
                    label={d !== null ? String(d) : ""}
                  />
                );
              })}
            </box>
          );
        }
        return rows;
      })()}
    </box>
  );
}

// ── Weather Section ───────────────────────────────────────────────────────────

function WeatherSection() {
  const [data, setData] = createSignal<WeatherData | null>(null);

  async function refresh() {
    const w = await fetchWeather();
    setData(w);
  }
  refresh();
  // re-fetch every 10 minutes
  const _poll = createPoll(null, 600000, async () => { await refresh(); return null; });

  return (
    <box class="cc-section cc-weather" vertical>
      {() => {
        const w = data();
        if (!w) return (
          <label class="cc-loading" label="Fetching weather…" />
        );

        return (
          <box vertical>
            {/* Current conditions */}
            <box class="weather-current">
              <label class="weather-big-icon" label={w.current.icon} />
              <box vertical halign={Gtk.Align.START} valign={Gtk.Align.CENTER}>
                <label class="weather-big-temp"  label={w.current.temp} halign={Gtk.Align.START} />
                <label class="weather-big-desc"  label={w.current.desc} halign={Gtk.Align.START} />
              </box>
            </box>

            {/* Details row */}
            <box class="weather-details">
              <box class="weather-detail-item" vertical>
                <label class="detail-icon" label="󰖖" />
                <label class="detail-val"  label={w.current.feelsLike} />
                <label class="detail-lbl"  label="Feels like" />
              </box>
              <box class="weather-detail-item" vertical>
                <label class="detail-icon" label="󰖑" />
                <label class="detail-val"  label={w.current.humidity} />
                <label class="detail-lbl"  label="Humidity" />
              </box>
              <box class="weather-detail-item" vertical>
                <label class="detail-icon" label="󰖝" />
                <label class="detail-val"  label={`${w.current.windSpeed} ${w.current.windDir}`} />
                <label class="detail-lbl"  label="Wind" />
              </box>
            </box>

            {/* 5-day forecast */}
            <box class="weather-forecast">
              {w.forecast.map(day => (
                <box class="forecast-day" vertical hexpand>
                  <label class="forecast-dow"  label={day.date} halign={Gtk.Align.CENTER} />
                  <label class="forecast-icon" label={day.icon} halign={Gtk.Align.CENTER} />
                  <label class="forecast-hi"   label={day.high} halign={Gtk.Align.CENTER} />
                  <label class="forecast-lo"   label={day.low}  halign={Gtk.Align.CENTER} />
                </box>
              ))}
            </box>
          </box>
        );
      }}
    </box>
  );
}

// ── System Stats Section ──────────────────────────────────────────────────────

function StatBar({ value, color }: { value: number; color: string }) {
  // value 0–100, rendered as a CSS width on a child box
  const filled = Math.max(0, Math.min(100, value));
  return (
    <box class="stat-bar-track">
      <box
        class="stat-bar-fill"
        hexpand={false}
        css={`min-width: ${filled * 1.4}px; background: ${color};`}
      />
    </box>
  );
}

function SystemSection() {
  const cpu = createPoll(0, 2000, async () => {
    const v = await sh("top -bn1 | grep 'Cpu(s)' | awk '{print int($2)}'", "0");
    return parseInt(v) || 0;
  });
  const ram = createPoll(0, 2000, async () => {
    const v = await sh("free | awk '/Mem:/ {printf \"%.0f\", $3/$2 * 100}'", "0");
    return parseInt(v) || 0;
  });
  const cpuTemp = createPoll("──°", 5000, async () => {
    const v = await sh("sensors | grep 'Tctl' | awk '{print int($2)}'", "──");
    return `${v}°`;
  });
  const gpuTemp = createPoll("──°", 5000, async () => {
    const v = await sh(
      "nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader 2>/dev/null || echo ──",
      "──",
    );
    return `${v}°`;
  });
  const gpuUtil = createPoll(0, 2000, async () => {
    const v = await sh(
      "nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits 2>/dev/null || echo 0",
      "0",
    );
    return parseInt(v) || 0;
  });

  return (
    <box class="cc-section cc-system" vertical>
      <label class="cc-section-title" label="System" halign={Gtk.Align.START} />

      {/* CPU */}
      <box class="sys-row">
        <label class="sys-icon" label="󰻠" />
        <label class="sys-label" label="CPU" />
        <StatBar value={cpu()} color="rgba(122,162,247,0.85)" />
        <label class="sys-val" label={`${cpu()}%`} />
        <label class="sys-temp" label={cpuTemp()} />
      </box>

      {/* RAM */}
      <box class="sys-row">
        <label class="sys-icon" label="󰍛" />
        <label class="sys-label" label="RAM" />
        <StatBar value={ram()} color="rgba(158,206,106,0.85)" />
        <label class="sys-val" label={`${ram()}%`} />
      </box>

      {/* GPU */}
      <box class="sys-row">
        <label class="sys-icon" label="󰢮" />
        <label class="sys-label" label="GPU" />
        <StatBar value={gpuUtil()} color="rgba(255,158,100,0.85)" />
        <label class="sys-val" label={`${gpuUtil()}%`} />
        <label class="sys-temp" label={gpuTemp()} />
      </box>
    </box>
  );
}

// ── Volume Section ────────────────────────────────────────────────────────────

function VolumeSection() {
  const [vol, setVol] = createSignal(75);

  // Read current volume on mount
  sh("wpctl get-volume @DEFAULT_AUDIO_SINK@ | awk '{print int($2 * 100)}'", "75")
    .then(v => setVol(parseInt(v) || 75));

  async function setVolume(pct: number) {
    const clamped = Math.max(0, Math.min(100, pct));
    setVol(clamped);
    await sh(`wpctl set-volume @DEFAULT_AUDIO_SINK@ ${clamped}%`, "");
  }

  function volIcon(v: number) {
    if (v === 0) return "󰝟";
    if (v < 33)  return "󰕿";
    if (v < 66)  return "󰖀";
    return "󰕾";
  }

  return (
    <box class="cc-section cc-volume" vertical>
      <label class="cc-section-title" label="Volume" halign={Gtk.Align.START} />
      <box class="vol-row">
        <label class="vol-icon" label={volIcon(vol())} />
        {/* Slider built from buttons since GTK scale needs extra wiring */}
        <box class="vol-track" hexpand>
          <box
            class="vol-fill"
            hexpand={false}
            css={`min-width: ${vol() * 5.6}px;`}
          />
          {/* Click zones — 10 segments */}
          {Array.from({ length: 10 }, (_, i) => (
            <button
              class="vol-segment"
              hexpand
              onClicked={() => setVolume((i + 1) * 10)}
            />
          ))}
        </box>
        <label class="vol-val" label={`${vol()}%`} />
      </box>
    </box>
  );
}

// ── Control Center Window ─────────────────────────────────────────────────────

export function ControlCenter({ gdkmonitor }: { gdkmonitor: Gdk.Monitor }) {
  let win: Astal.Window;
  const { TOP, LEFT, RIGHT } = Astal.WindowAnchor;

  onCleanup(() => win?.destroy());

  // Drive opacity + margin-top via CSS transition for the slide+fade effect
  const visible = ccVisible;

  return (
    <window
      $={(self) => (win = self)}
      visible
      name="control-center"
      gdkmonitor={gdkmonitor}
      exclusivity={Astal.Exclusivity.NORMAL}
      anchor={TOP | LEFT | RIGHT}
      application={app}
      css="background: transparent;"
    >
      <box halign={Gtk.Align.CENTER} valign={Gtk.Align.START}>
        <box
          class="cc-root"
          vertical
          css={visible()
            ? "opacity: 1; margin-top: 8px;"
            : "opacity: 0; margin-top: -20px;"}
        >
          {/* Top row: Calendar + Weather */}
          <box class="cc-top-row">
            <CalendarSection />
            <WeatherSection />
          </box>

          {/* Bottom row: System + Volume */}
          <box class="cc-bottom-row">
            <SystemSection />
            <VolumeSection />
          </box>
        </box>
      </box>
    </window>
  );
}
