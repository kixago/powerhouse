import { createSignal } from "ags";

// Single shared signal so Clock, Weather, and the window all share state
export const [ccVisible, setCCVisible] = createSignal(false);

export function toggleCC() {
  setCCVisible(!ccVisible());
}
